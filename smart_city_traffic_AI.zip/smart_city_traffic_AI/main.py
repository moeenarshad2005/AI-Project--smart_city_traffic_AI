"""
============================================================
Smart City Traffic & Emergency Response AI System
Main Entry Point
============================================================
Purpose:
    Runs the complete AI traffic management system
    using preprocessing, ANN, KB, CSP, and Search modules.
============================================================
"""

from modules.input_preprocessing import InputPreprocessing
from modules.request_router import RequestRouter
from modules.ann_priority import ANNPriorityModule
from modules.knowledge_base import KnowledgeBaseModule
from modules.csp_scheduler import CSPScheduler
from modules.search_navigation import SearchNavigation
from modules.final_response import FinalResponseLayer
import json


# Display system title
def print_banner():

    print("\n" + "=" * 65)
    print("   SMART CITY TRAFFIC & EMERGENCY RESPONSE AI SYSTEM")
    print("   AL-2002 Artificial Intelligence Lab — Final Project")
    print("=" * 65)


# Display menu
def print_menu():

    print("\n┌─────────────────────────────────────────────┐")
    print("│              SELECT REQUEST TYPE             │")
    print("├──────────────────────────────────────────────┤")
    print("│  1. Route_Request                            │")
    print("│  2. Policy_Check                             │")
    print("│  3. Control_Allocation_Request               │")
    print("│  4. Emergency_Response_Request               │")
    print("│  5. Integrated_City_Service_Request          │")
    print("│  6. Run Demo Scenarios                       │")
    print("│  7. Exit                                     │")
    print("└──────────────────────────────────────────────┘")


# Show available locations
def get_locations():

    locations = [
        "Central_Junction", "North_Station", "East_Market",
        "South_Residential", "River_Bridge", "City_Hospital",
        "Police_HQ", "Fire_Station", "Traffic_Control_Center",
        "Airport_Road", "West_Terminal", "Industrial_Zone", "Stadium"
    ]

    print("\nAvailable City Locations:")

    for i, loc in enumerate(locations, 1):
        print(f"  {i:2}. {loc}")

    return locations


# Collect request data from user
def collect_basic_input(request_category):

    print(f"\n--- Input for: {request_category} ---")

    locations = get_locations()

    request = {}
    request["request_category"] = request_category

    # Request ID
    request["request_id"] = input("\nEnter Request ID: ").strip() or "REQ-001"

    # Vehicle type
    print("\nVehicle Types: 1=Ambulance  2=FireTruck  3=Police  4=Civilian")

    vtype = input("Select vehicle type [1-4]: ").strip()

    vtypes = {
        "1": "Ambulance",
        "2": "FireTruck",
        "3": "Police",
        "4": "Civilian"
    }

    request["vehicle_type"] = vtypes.get(vtype, "Civilian")

    # Current location
    print()

    loc_input = input("Current Location: ").strip()

    if loc_input.isdigit() and 1 <= int(loc_input) <= len(locations):
        request["current_location"] = locations[int(loc_input) - 1]
    else:
        request["current_location"] = loc_input if loc_input else "Central_Junction"

    # Destination
    dest_input = input("Destination: ").strip()

    if dest_input.isdigit() and 1 <= int(dest_input) <= len(locations):
        request["destination"] = locations[int(dest_input) - 1]
    else:
        request["destination"] = dest_input if dest_input else "City_Hospital"

    # Emergency fields
    if request_category in [
        "Emergency_Response_Request",
        "Integrated_City_Service_Request"
    ]:

        print("\nIncident Severity: 1=Low  2=Medium  3=High  4=Critical")

        sev = input("Select severity [1-4]: ").strip()

        sevs = {
            "1": "Low",
            "2": "Medium",
            "3": "High",
            "4": "Critical"
        }

        request["incident_severity"] = sevs.get(sev, "High")

        ts = input("Time sensitive? (y/n): ").strip().lower()
        request["time_sensitivity"] = "High" if ts == "y" else "Normal"

        print("\nTraffic Density: 1=Low  2=Medium  3=High")

        td = input("Select traffic density [1-3]: ").strip()

        tds = {
            "1": "Low",
            "2": "Medium",
            "3": "High"
        }

        request["traffic_density"] = tds.get(td, "High")

        pc = input("Priority claim? (y/n): ").strip().lower()
        request["priority_claim"] = "Yes" if pc == "y" else "No"

    else:

        request["incident_severity"] = "None"
        request["time_sensitivity"] = "Normal"
        request["traffic_density"] = "Medium"
        request["priority_claim"] = "No"

    # Control zone
    if request_category in [
        "Policy_Check",
        "Control_Allocation_Request",
        "Integrated_City_Service_Request"
    ]:

        request["control_zone"] = (
            input("\nEnter control zone: ").strip()
            or "Central_Zone"
        )

    else:
        request["control_zone"] = "Central_Zone"

    # Optional note
    request["description_note"] = input(
        "\nDescription note: "
    ).strip()

    return request


# Run complete pipeline
def run_pipeline(request_data):

    print("\n" + "=" * 65)
    print("   PROCESSING REQUEST...")
    print("=" * 65)

    # Step 1: Preprocessing
    print("\n[Step 1] Input & Preprocessing Module")

    preprocessor = InputPreprocessing()

    processed = preprocessor.process(request_data)

    if not processed["valid"]:

        print(f"  Validation failed: {processed['errors']}")
        return

    print("  Request validated successfully.")

    # Step 2: Request Router
    print("\n[Step 2] Request Router")

    router = RequestRouter()

    pipeline = router.route(processed)

    print(f"  Pipeline: {' → '.join(pipeline)}")

    results = {
        "request": processed,
        "pipeline": pipeline
    }

    # Step 3: ANN
    ann_result = None

    if "ANN" in pipeline:

        print("\n[Step 3] ANN Priority Module")

        ann_module = ANNPriorityModule()

        ann_result = ann_module.predict(processed)

        results["ann"] = ann_result

        print(f"  Priority: {ann_result['priority_label']}")

    # Step 4: Knowledge Base
    kb_result = None

    if "KB" in pipeline:

        print("\n[Step 4] Knowledge Base Module")

        kb_module = KnowledgeBaseModule()

        kb_result = kb_module.validate(processed, ann_result)

        results["kb"] = kb_result

        if kb_result["approved"]:
            print("  Request Approved")
        else:
            print("  Request Rejected")

    # Step 5: CSP Scheduler
    csp_result = None

    if "CSP" in pipeline:

        print("\n[Step 5] CSP Scheduler Module")

        csp = CSPScheduler()

        csp_result = csp.allocate(processed, kb_result)

        results["csp"] = csp_result

        if csp_result["feasible"]:
            print("  Control allocation completed")
        else:
            print("  No feasible control plan found")

    # Step 6: Search Module
    search_result = None

    if "Search" in pipeline:

        print("\n[Step 6] Search & Navigation Module")

        search = SearchNavigation()

        search_result = search.find_route(processed, csp_result)

        results["search"] = search_result

        if search_result["path"]:

            print(f"  Algorithm: {search_result['algorithm']}")

            print(
                f"  Route: {' → '.join(search_result['path'])}"
            )

        else:
            print("  No route found")

    # Step 7: Final Response
    print("\n[Step 7] Final Response Layer")

    final = FinalResponseLayer()

    response = final.generate(results)

    print("\n" + "=" * 65)
    print("   FINAL SYSTEM RESPONSE")
    print("=" * 65)

    print(response)

    print("=" * 65)


# Run demo examples
def run_demo_scenarios():

    demos = [

        {
            "name": "Demo 1",
            "data": {
                "request_id": "DEMO-001",
                "vehicle_type": "Civilian",
                "request_category": "Route_Request",
                "current_location": "Stadium",
                "destination": "East_Market",
                "incident_severity": "None",
                "time_sensitivity": "Normal",
                "traffic_density": "Medium",
                "priority_claim": "No",
                "control_zone": "Central_Zone",
                "description_note": "Civilian route request"
            }
        },

        {
            "name": "Demo 2",
            "data": {
                "request_id": "DEMO-002",
                "vehicle_type": "Ambulance",
                "request_category": "Emergency_Response_Request",
                "current_location": "Central_Junction",
                "destination": "City_Hospital",
                "incident_severity": "High",
                "time_sensitivity": "High",
                "traffic_density": "High",
                "priority_claim": "Yes",
                "control_zone": "Central_Zone",
                "description_note": "Emergency response"
            }
        }
    ]

    for demo in demos:

        input(f"\nPress Enter to run {demo['name']}...")

        run_pipeline(demo["data"])


# Main function
def main():

    print_banner()

    category_map = {
        "1": "Route_Request",
        "2": "Policy_Check",
        "3": "Control_Allocation_Request",
        "4": "Emergency_Response_Request",
        "5": "Integrated_City_Service_Request",
    }

    while True:

        print_menu()

        choice = input("\nEnter choice [1-7]: ").strip()

        if choice == "7":

            print("\nExiting system...\n")
            break

        elif choice == "6":

            run_demo_scenarios()

        elif choice in category_map:

            category = category_map[choice]

            try:
                request_data = collect_basic_input(category)
                run_pipeline(request_data)

            except KeyboardInterrupt:
                print("\nCancelled by user")

        else:
            print("Invalid choice")


if __name__ == "__main__":
    main()