"""
============================================================
Module 2: Request Router
============================================================
Purpose:
    Selects the correct AI module pipeline based
    on the request category.
============================================================
"""


class RequestRouter:

    # Request category pipelines
    PIPELINE_MAP = {

        "Route_Request": [
            "Search"
        ],

        "Policy_Check": [
            "KB"
        ],

        "Control_Allocation_Request": [
            "KB",
            "CSP"
        ],

        "Emergency_Response_Request": [
            "ANN",
            "KB",
            "CSP",
            "Search"
        ],

        "Integrated_City_Service_Request": [
            "ANN",
            "KB",
            "CSP",
            "Search"
        ],
    }

    # Module display names
    MODULE_LABELS = {

        "ANN": "ANN Priority Prediction",

        "KB": "Logic / Knowledge Base",

        "CSP": "CSP Scheduler",

        "Search": "Search & Navigation",
    }

    # Select pipeline
    def route(self, processed_request):

        category = processed_request.get(
            "request_category",
            "Route_Request"
        )

        pipeline = self.PIPELINE_MAP.get(
            category,
            ["Search"]
        )

        return pipeline

    # Convert pipeline into readable text
    def describe_pipeline(self, pipeline):

        labels = [
            self.MODULE_LABELS.get(m, m)
            for m in pipeline
        ]

        return " → ".join(labels)