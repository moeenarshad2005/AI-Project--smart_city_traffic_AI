"""
============================================================
Module 6: Search & Navigation Module
============================================================
Purpose:
    Finds routes in the city road network using
    BFS, UCS, and A* search algorithms.
============================================================
"""

import heapq
from collections import deque


class SearchNavigation:

    # Unweighted graph for BFS
    UNWEIGHTED_GRAPH = {
        "Police_HQ": ["Traffic_Control_Center", "River_Bridge"],
        "Traffic_Control_Center": ["Police_HQ", "North_Station"],
        "North_Station": ["Traffic_Control_Center", "River_Bridge", "Central_Junction"],
        "River_Bridge": ["Police_HQ", "North_Station", "Stadium", "Central_Junction"],
        "Stadium": ["River_Bridge", "East_Market", "Airport_Road"],
        "Central_Junction": [
            "North_Station", "River_Bridge", "East_Market",
            "West_Terminal", "South_Residential"
        ],
        "East_Market": [
            "Stadium", "Central_Junction",
            "South_Residential", "Industrial_Zone"
        ],
        "West_Terminal": [
            "Central_Junction", "Fire_Station", "Industrial_Zone"
        ],
        "Fire_Station": ["West_Terminal"],
        "South_Residential": [
            "Central_Junction", "East_Market",
            "City_Hospital", "Airport_Road"
        ],
        "City_Hospital": ["South_Residential", "East_Market"],
        "Airport_Road": ["Stadium", "South_Residential"],
        "Industrial_Zone": ["East_Market", "West_Terminal"],
    }

    # Weighted graph for UCS and A*
    WEIGHTED_GRAPH = {
        "Police_HQ": [("Traffic_Control_Center", 2), ("River_Bridge", 2)],
        "Traffic_Control_Center": [("Police_HQ", 2), ("Airport_Road", 2)],
        "North_Station": [("Central_Junction", 3), ("River_Bridge", 4)],
        "River_Bridge": [
            ("Police_HQ", 2),
            ("North_Station", 4),
            ("Central_Junction", 3)
        ],
        "Central_Junction": [
            ("North_Station", 3),
            ("River_Bridge", 3),
            ("East_Market", 3),
            ("West_Terminal", 2),
            ("South_Residential", 4)
        ],
        "East_Market": [
            ("Central_Junction", 3),
            ("Stadium", 3),
            ("City_Hospital", 3),
            ("Industrial_Zone", 3)
        ],
        "West_Terminal": [
            ("Central_Junction", 2),
            ("Fire_Station", 2),
            ("Industrial_Zone", 4)
        ],
        "Fire_Station": [("West_Terminal", 2)],
        "South_Residential": [
            ("Central_Junction", 4),
            ("Airport_Road", 5)
        ],
        "City_Hospital": [("East_Market", 3)],
        "Airport_Road": [
            ("Traffic_Control_Center", 2),
            ("South_Residential", 5),
            ("Stadium", 3)
        ],
        "Stadium": [
            ("East_Market", 3),
            ("Airport_Road", 3)
        ],
        "Industrial_Zone": [
            ("East_Market", 3),
            ("West_Terminal", 4)
        ],
    }

    # Heuristic values for A*
    HEURISTIC_TO_HOSPITAL = {
        "Central_Junction": 3,
        "East_Market": 3,
        "South_Residential": 2,
        "West_Terminal": 5,
        "North_Station": 6,
        "River_Bridge": 7,
        "Police_HQ": 9,
        "Traffic_Control_Center": 10,
        "Stadium": 6,
        "Airport_Road": 7,
        "Fire_Station": 6,
        "Industrial_Zone": 4,
        "City_Hospital": 0,
    }

    # Heuristic function
    def _heuristic(self, node, goal):
        if goal == "City_Hospital":
            return self.HEURISTIC_TO_HOSPITAL.get(node, 5)
        return 0

    # Breadth First Search
    def bfs(self, start, goal):

        if start == goal:
            return [start]

        if start not in self.UNWEIGHTED_GRAPH:
            return None

        visited = {start}
        queue = deque([[start]])

        while queue:
            path = queue.popleft()
            current = path[-1]

            for neighbor in self.UNWEIGHTED_GRAPH.get(current, []):

                if neighbor not in visited:
                    new_path = path + [neighbor]

                    if neighbor == goal:
                        return new_path

                    visited.add(neighbor)
                    queue.append(new_path)

        return None

    # Uniform Cost Search
    def ucs(self, start, goal):

        if start == goal:
            return [start], 0

        if start not in self.WEIGHTED_GRAPH:
            return None, None

        heap = [(0, [start])]
        visited = {}

        while heap:
            cost, path = heapq.heappop(heap)
            current = path[-1]

            if current in visited and visited[current] <= cost:
                continue

            visited[current] = cost

            if current == goal:
                return path, cost

            for neighbor, edge_cost in self.WEIGHTED_GRAPH.get(current, []):

                new_cost = cost + edge_cost

                if neighbor not in visited or visited.get(neighbor, float("inf")) > new_cost:
                    heapq.heappush(heap, (new_cost, path + [neighbor]))

        return None, None

    # A* Search
    def astar(self, start, goal):

        if start == goal:
            return [start], 0

        if start not in self.WEIGHTED_GRAPH:
            return None, None

        h0 = self._heuristic(start, goal)

        heap = [(h0, 0, [start])]
        visited = {}

        while heap:
            f, g, path = heapq.heappop(heap)
            current = path[-1]

            if current in visited and visited[current] <= g:
                continue

            visited[current] = g

            if current == goal:
                return path, g

            for neighbor, edge_cost in self.WEIGHTED_GRAPH.get(current, []):

                new_g = g + edge_cost
                h = self._heuristic(neighbor, goal)
                new_f = new_g + h

                if neighbor not in visited or visited.get(neighbor, float("inf")) > new_g:
                    heapq.heappush(heap, (new_f, new_g, path + [neighbor]))

        return None, None

    # Main route finder
    def find_route(self, processed_request, csp_result=None):

        src = processed_request.get("current_location", "")
        dst = processed_request.get("destination", "")
        category = processed_request.get("request_category", "Route_Request")
        is_emergency = processed_request.get("is_emergency_vehicle", False)

        # Validate locations
        if src not in self.UNWEIGHTED_GRAPH:
            return {
                "algorithm": "None",
                "path": None,
                "total_cost": None,
                "hops": None,
                "message": f"Source '{src}' not found.",
            }

        if dst not in self.UNWEIGHTED_GRAPH:
            return {
                "algorithm": "None",
                "path": None,
                "total_cost": None,
                "hops": None,
                "message": f"Destination '{dst}' not found.",
            }

        # Use BFS for civilian route requests
        if category == "Route_Request" and not is_emergency:

            path = self.bfs(src, dst)

            if path:
                return {
                    "algorithm": "BFS",
                    "path": path,
                    "total_cost": None,
                    "hops": len(path) - 1,
                    "message": "Shortest hop route found.",
                }

            return {
                "algorithm": "BFS",
                "path": None,
                "total_cost": None,
                "hops": None,
                "message": "No route found.",
            }

        # Use A* for emergency hospital routes
        elif is_emergency and dst == "City_Hospital":

            path, cost = self.astar(src, dst)

            if path:
                return {
                    "algorithm": "A*",
                    "path": path,
                    "total_cost": cost,
                    "hops": len(path) - 1,
                    "message": "Emergency route found.",
                }

            return {
                "algorithm": "A*",
                "path": None,
                "total_cost": None,
                "hops": None,
                "message": "No route found.",
            }

        # Use UCS for all other cases
        else:

            path, cost = self.ucs(src, dst)

            if path:
                return {
                    "algorithm": "UCS",
                    "path": path,
                    "total_cost": cost,
                    "hops": len(path) - 1,
                    "message": "Lowest cost route found.",
                }

            return {
                "algorithm": "UCS",
                "path": None,
                "total_cost": None,
                "hops": None,
                "message": "No route found.",
            }