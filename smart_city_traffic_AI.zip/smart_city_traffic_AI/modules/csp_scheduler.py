"""Module 5: CSP Scheduler / Control Allocation Module"""
class CSPScheduler:
    
    # Signal stations from the CSP graph in the project spec
    STATIONS = {
        "S1": {"name": "Central_Junction",  "phases": ["PhaseA", "PhaseB"]},
        "S2": {"name": "North_Station",     "phases": ["PhaseA", "PhaseB", "PhaseC"]},
        "S3": {"name": "East_Market",       "phases": ["PhaseB", "PhaseC"]},
        "S4": {"name": "River_Bridge",      "phases": ["PhaseA", "PhaseC"]},
        "S5": {"name": "City_Hospital",     "phases": ["PhaseB", "PhaseC"]},
    }

    # Conflict pairs: these station pairs cannot share the same phase
    CONFLICTS = [
        ("S1", "S2"),  # in-conflict
        ("S1", "S3"),  # in-conflict
        ("S2", "S4"),  # coordination (must differ)
    ]

    # Precedence/priority pairs: S3→S5 precedence, S4→S5 emergency
    PRECEDENCE = [
        ("S3", "S5"),  # precedence corridor: S5 phase must follow S3
        ("S4", "S5"),  # emergency priority path
    ]

    # Location → Station ID mapping
    LOCATION_TO_STATION = {
        "Central_Junction": "S1",
        "North_Station": "S2",
        "East_Market": "S3",
        "River_Bridge": "S4",
        "City_Hospital": "S5",
    }

    def _get_relevant_stations(self, processed_request):
        """
        Determine which stations are relevant based on source,
        destination, and any intermediate known nodes.
        Returns station IDs to include in the CSP.
        """
        src = processed_request.get("current_location", "")
        dst = processed_request.get("destination", "")

        relevant = set()
        if src in self.LOCATION_TO_STATION:
            relevant.add(self.LOCATION_TO_STATION[src])
        if dst in self.LOCATION_TO_STATION:
            relevant.add(self.LOCATION_TO_STATION[dst])

        # Always include adjacent conflict stations for completeness
        for s1, s2 in self.CONFLICTS:
            if s1 in relevant or s2 in relevant:
                relevant.add(s1)
                relevant.add(s2)

        # If fewer than 3 stations, include all 5 for a meaningful CSP demo
        if len(relevant) < 3:
            relevant = set(self.STATIONS.keys())

        return list(relevant)

    def _is_consistent(self, station, phase, assignment, emergency_stations):
        """
        Check if assigning 'phase' to 'station' is consistent
        with all constraints given the current partial assignment.

        Parameters:
            station (str): Station ID being assigned.
            phase (str): Phase being considered.
            assignment (dict): Current partial assignment {station: phase}.
            emergency_stations (set): Stations on emergency corridor.

        Returns:
            bool: True if assignment is consistent, False otherwise.
        """
        # Emergency station must use PhaseC if available
        if station in emergency_stations:
            station_phases = self.STATIONS[station]["phases"]
            if "PhaseC" in station_phases and phase != "PhaseC":
                return False

        # Check conflict constraints (conflicting stations must have different phases)
        for s1, s2 in self.CONFLICTS:
            if s1 == station and s2 in assignment:
                if assignment[s2] == phase:
                    return False
            if s2 == station and s1 in assignment:
                if assignment[s1] == phase:
                    return False

        # Check precedence constraints (precedence pairs should ideally differ)
        for s_before, s_after in self.PRECEDENCE:
            if s_after == station and s_before in assignment:
                if assignment[s_before] == phase:
                    return False

        return True

    def _backtrack(self, stations, assignment, emergency_stations):
        """
        Backtracking search for a consistent phase assignment.
        Selects the next unassigned station and tries each valid phase.

        Parameters:
            stations (list): Ordered list of station IDs to assign.
            assignment (dict): Current partial assignment.
            emergency_stations (set): Stations requiring PhaseC priority.

        Returns:
            dict|None: Complete assignment or None if unsatisfiable.
        """
        if len(assignment) == len(stations):
            return assignment  # All stations assigned — solution found

        # Select next unassigned station
        unassigned = [s for s in stations if s not in assignment]
        station = unassigned[0]

        # Try each valid phase for this station
        valid_phases = self.STATIONS[station]["phases"]

        # Emergency stations: try PhaseC first
        if station in emergency_stations:
            if "PhaseC" in valid_phases:
                valid_phases = ["PhaseC"] + [p for p in valid_phases if p != "PhaseC"]

        for phase in valid_phases:
            if self._is_consistent(station, phase, assignment, emergency_stations):
                assignment[station] = phase
                result = self._backtrack(stations, assignment, emergency_stations)
                if result is not None:
                    return result
                del assignment[station]  # Backtrack

        return None  # No valid assignment found

    def allocate(self, processed_request, kb_result=None):
        """
        Run the CSP solver to find a valid signal phase assignment.

        Parameters:
            processed_request (dict): Validated request.
            kb_result (dict|None): Output from knowledge base module.

        Returns:
            dict: {
                'feasible': bool,
                'assignments': dict {station_id: phase},
                'station_names': dict {station_id: location_name},
                'emergency_stations': list,
                'message': str,
            }
        """
        # Determine relevant stations
        stations = self._get_relevant_stations(processed_request)

        # Determine which stations are on the emergency corridor
        emergency_stations = set()
        is_emergency = processed_request.get("is_emergency_vehicle", False)
        kb_approved = kb_result["approved"] if kb_result else False
        kb_priority = kb_result["priority"] if kb_result else "Normal"

        if is_emergency and kb_approved and kb_priority in {"High", "Critical"}:
            src = processed_request.get("current_location", "")
            dst = processed_request.get("destination", "")
            if src in self.LOCATION_TO_STATION:
                emergency_stations.add(self.LOCATION_TO_STATION[src])
            if dst in self.LOCATION_TO_STATION:
                emergency_stations.add(self.LOCATION_TO_STATION[dst])

        # Run backtracking CSP
        assignment = self._backtrack(stations, {}, emergency_stations)

        if assignment:
            # Build readable output
            station_names = {
                sid: self.STATIONS[sid]["name"]
                for sid in stations
            }
            msg = "Feasible control plan found. Signals coordinated."
            if emergency_stations:
                emg_names = [self.STATIONS[s]["name"] for s in emergency_stations if s in self.STATIONS]
                msg += f" Emergency PhaseC assigned to: {', '.join(emg_names)}."

            return {
                "feasible": True,
                "assignments": assignment,
                "station_names": station_names,
                "emergency_stations": list(emergency_stations),
                "message": msg,
            }
        else:
            return {
                "feasible": False,
                "assignments": {},
                "station_names": {},
                "emergency_stations": [],
                "message": "No feasible signal assignment found under current constraints.",
            }
