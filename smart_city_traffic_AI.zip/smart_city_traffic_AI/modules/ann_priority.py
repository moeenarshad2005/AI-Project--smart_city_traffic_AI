"""
Module 3: ANN Priority Prediction Module
"""

import math


# Sigmoid activation function
def sigmoid(x):
    x = max(-500, min(500, x))
    return 1.0 / (1.0 + math.exp(-x))


# ReLU activation function
def relu(x):
    return max(0.0, x)


# Softmax for probability output
def softmax(values):
    max_v = max(values)
    exp_vals = [math.exp(v - max_v) for v in values]
    total = sum(exp_vals)
    return [e / total for e in exp_vals]


# Neuron calculation
def dot_plus_bias(inputs, weights, bias):
    return sum(i * w for i, w in zip(inputs, weights)) + bias


class ANNPriorityModule:

    # Priority labels
    PRIORITY_LABELS = ["Low", "Normal", "High", "Critical"]

    # Binary classifier weights
    BIN_W1 = [
        [0.8, 1.0, 0.5, 0.4, 0.1, 0.7],
        [0.3, 0.6, 1.2, 0.9, 0.1, 0.5],
        [0.5, 0.8, 0.3, 0.2, 0.0, 1.1],
        [0.6, 0.7, 0.6, 0.5, 0.2, 0.6],
    ]
    BIN_B1 = [-1.5, -1.0, -1.2, -1.4]

    BIN_W2 = [1.2, 1.1, 1.3, 1.0]
    BIN_B2 = -2.0

    # Multi-class classifier weights
    MLC_W1 = [
        [0.9, 1.1, 0.6, 0.5, 0.05, 0.8],
        [0.3, 0.4, 1.3, 1.0, 0.05, 0.4],
        [0.5, 0.9, 0.4, 0.3, 0.02, 1.2],
        [0.7, 0.8, 0.7, 0.6, 0.1, 0.7],
        [1.0, 0.6, 0.3, 0.2, 0.02, 0.5],
        [0.2, 1.2, 0.5, 0.8, 0.1, 0.6],
        [0.8, 0.7, 0.8, 0.5, 0.15, 0.9],
        [0.4, 0.5, 0.6, 0.9, 0.1, 0.8],
    ]
    MLC_B1 = [-0.5, -0.8, -0.7, -0.6, -0.4, -0.9, -0.7, -0.8]

    MLC_W2 = [
        [1.2, 0.8, 1.0, 0.9, 1.1, 0.7, 1.0, 0.8],
        [0.6, 1.0, 0.7, 0.8, 0.5, 0.9, 0.7, 0.8],
        [0.3, 0.4, 0.3, 0.4, 0.3, 0.4, 0.3, 0.4],
        [0.1, 0.2, 0.1, 0.2, 0.1, 0.2, 0.1, 0.2],
    ]
    MLC_B2 = [-1.5, -1.2, -0.5, 0.2]

    MLC_W3 = [
        [-0.5, -0.3, 0.4, 1.2],
        [-0.3, 0.3, 1.3, -0.3],
        [0.4, 1.4, -0.2, -0.5],
        [1.5, 0.2, -0.5, -0.8],
    ]
    MLC_B3 = [0.3, 0.2, -0.2, -0.5]

    def _binary_forward(self, features):

        # Normalize inputs
        norm = [
            features[0] / 3.0,
            features[1] / 4.0,
            features[2],
            features[3] / 2.0,
            features[4] / 8.0,
            features[5],
        ]

        # Hidden layer
        h1 = []
        for w, b in zip(self.BIN_W1, self.BIN_B1):
            h1.append(sigmoid(dot_plus_bias(norm, w, b)))

        # Output layer
        out = dot_plus_bias(h1, self.BIN_W2, self.BIN_B2)

        return sigmoid(out)

    def _multiclass_forward(self, features):

        # Normalize inputs
        norm = [
            features[0] / 3.0,
            features[1] / 4.0,
            features[2],
            features[3] / 2.0,
            features[4] / 8.0,
            features[5],
        ]

        # Hidden layer 1
        h1 = []
        for w, b in zip(self.MLC_W1, self.MLC_B1):
            h1.append(relu(dot_plus_bias(norm, w, b)))

        # Hidden layer 2
        h2 = []
        for w, b in zip(self.MLC_W2, self.MLC_B2):
            h2.append(relu(dot_plus_bias(h1, w, b)))

        # Output layer
        logits = []
        for w, b in zip(self.MLC_W3, self.MLC_B3):
            logits.append(dot_plus_bias(h2, w, b))

        return softmax(logits)

    def predict(self, processed_request):

        features = processed_request.get("ann_features", [0, 0, 0, 1, 3, 0])

        # Binary prediction
        prob = self._binary_forward(features)
        binary = 1 if prob >= 0.5 else 0

        # Multi-class prediction
        probs = self._multiclass_forward(features)
        idx = probs.index(max(probs))

        return {
            "binary": binary,
            "binary_confidence": round(prob, 3),
            "priority_label": self.PRIORITY_LABELS[idx],
            "priority_index": idx,
            "scores": {
                label: round(p, 3)
                for label, p in zip(self.PRIORITY_LABELS, probs)
            }
        }