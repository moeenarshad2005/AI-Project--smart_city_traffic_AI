"""Module 4: Logic / Knowledge Base Module"""


class KnowledgeBaseModule:

    # Main validation function
    def validate(self, processed_request, ann_result=None):

        # Extract request data
        vehicle_type = processed_request["vehicle_type"]

        category = processed_request["request_category"]

        severity = processed_request["incident_severity"]

        time_sensitive = (
            processed_request["time_sensitivity"] == "High"
        )

        destination = processed_request["destination"]

        control_zone = processed_request.get(
            "control_zone",
            "Central_Zone"
        )

        # Get ANN priority if available
        ann_priority = (
            ann_result["priority_label"]
            if ann_result else None
        )

        # Store facts
        facts = set()

        derived_facts = []

        # Vehicle checks
        is_emergency = vehicle_type in {
            "Ambulance",
            "FireTruck",
            "Police"
        }

        is_civilian = vehicle_type == "Civilian"

        is_hospital_dest = (
            destination == "City_Hospital"
        )

        in_signal_zone = True

        # Vehicle type facts
        if is_emergency:

            facts.add("EmergencyVehicle")

            derived_facts.append(
                f"EmergencyVehicle({vehicle_type})"
            )

        if is_civilian:

            facts.add("CivilianVehicle")

            derived_facts.append(
                f"CivilianVehicle({vehicle_type})"
            )

        # Default priority
        priority = "Normal"

        # ANN-based priority
        if ann_priority in {
            "Critical",
            "High",
            "Normal",
            "Low"
        } if ann_priority else False:

            if is_emergency and ann_priority == "Critical":

                priority = "Critical"

                derived_facts.append(
                    "ANN → Priority(Critical)"
                )

            elif is_emergency and ann_priority == "High":

                priority = "High"

                derived_facts.append(
                    "ANN → Priority(High)"
                )

            elif is_civilian:

                priority = "Normal"

                derived_facts.append(
                    "Civilian → Priority(Normal)"
                )

            else:

                priority = ann_priority

        else:

            # Rule-based priority
            if is_emergency and severity in {
                "High",
                "Critical"
            }:

                priority = "Critical"

                derived_facts.append(
                    "Emergency + High Severity → Critical"
                )

            elif is_emergency and time_sensitive:

                priority = "High"

                derived_facts.append(
                    "Emergency + Time Sensitive → High"
                )

            elif is_civilian:

                priority = "Normal"

                derived_facts.append(
                    "Civilian → Normal"
                )

        facts.add(f"Priority_{priority}")

        derived_facts.append(
            f"Derived Priority: {priority}"
        )

        # Authorized actions
        authorized_actions = []

        if is_emergency and in_signal_zone:

            authorized_actions.append(
                "SignalOverride"
            )

            derived_facts.append(
                "EmergencyVehicle → Authorized(SignalOverride)"
            )

        elif is_civilian and in_signal_zone:

            derived_facts.append(
                "Civilian → Not Authorized(SignalOverride)"
            )

        # Emergency corridor
        emergency_corridor = False

        if is_emergency and is_hospital_dest:

            emergency_corridor = True

            facts.add("EmergencyCorridor")

            derived_facts.append(
                "EmergencyVehicle + Hospital → EmergencyCorridor"
            )

            authorized_actions.append(
                "EmergencyRoute"
            )

            derived_facts.append(
                "EmergencyCorridor → Authorized(EmergencyRoute)"
            )

        elif is_emergency:

            authorized_actions.append(
                "EmergencyRoute"
            )

            derived_facts.append(
                "EmergencyVehicle → Authorized(EmergencyRoute)"
            )

        # Allowed actions
        allowed_actions = []

        for action in authorized_actions:

            allowed_actions.append(action)

            derived_facts.append(
                f"Authorized({action}) → AllowedAction({action})"
            )

        # Critical emergency rule
        if (
            priority == "Critical"
            and "EmergencyRoute" in authorized_actions
        ):

            if "SignalOverride" not in allowed_actions:

                allowed_actions.append(
                    "SignalOverride"
                )

                derived_facts.append(
                    "Critical Priority → Allowed(SignalOverride)"
                )

        # Approval decision
        approved = False

        # Route request
        if category == "Route_Request":

            approved = True

            derived_facts.append(
                "Route_Request → Approved"
            )

        # Policy check
        elif category == "Policy_Check":

            if authorized_actions:

                approved = True

                derived_facts.append(
                    "Authorized → Approved"
                )

            else:

                approved = False

                derived_facts.append(
                    "Not Authorized → Rejected"
                )

        # Control allocation
        elif category == "Control_Allocation_Request":

            if allowed_actions:

                approved = True

                derived_facts.append(
                    "AllowedAction → Approved"
                )

            else:

                approved = False

                derived_facts.append(
                    "No AllowedAction → Rejected"
                )

        # Emergency response
        elif category == "Emergency_Response_Request":

            if (
                priority in {"High", "Critical"}
                and "EmergencyRoute" in authorized_actions
            ):

                approved = True

                derived_facts.append(
                    "Emergency Request → Approved"
                )

            else:

                approved = False

                derived_facts.append(
                    "Emergency Request → Rejected"
                )

        # Integrated service
        elif category == "Integrated_City_Service_Request":

            if (
                priority == "Critical"
                and "EmergencyRoute" in authorized_actions
                and allowed_actions
            ):

                approved = True

                derived_facts.append(
                    "Integrated Service → Approved"
                )

            elif (
                priority == "High"
                and "EmergencyRoute" in authorized_actions
            ):

                approved = True

                derived_facts.append(
                    "Integrated Service High Priority → Approved"
                )

            else:

                approved = False

                derived_facts.append(
                    "Integrated Service → Rejected"
                )

        # Final output
        return {
            "approved": approved,
            "derived_facts": derived_facts,
            "priority": priority,
            "authorized_actions": authorized_actions,
            "allowed_actions": allowed_actions,
            "emergency_corridor": emergency_corridor,
        }