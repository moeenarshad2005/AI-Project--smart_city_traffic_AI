"""Module 1: Input & Preprocessing"""


class InputPreprocessing:

    # Allowed values
    VALID_VEHICLE_TYPES = {"Ambulance", "FireTruck", "Police", "Civilian"}

    VALID_CATEGORIES = {
        "Route_Request",
        "Policy_Check",
        "Control_Allocation_Request",
        "Emergency_Response_Request",
        "Integrated_City_Service_Request",
    }

    VALID_SEVERITIES = {"None", "Low", "Medium", "High", "Critical"}

    VALID_SENSITIVITIES = {"Normal", "High"}

    VALID_DENSITIES = {"Low", "Medium", "High"}

    VALID_PRIORITY_CLAIMS = {"Yes", "No"}

    VALID_LOCATIONS = {
        "Central_Junction", "North_Station", "East_Market",
        "South_Residential", "River_Bridge", "City_Hospital",
        "Police_HQ", "Fire_Station", "Traffic_Control_Center",
        "Airport_Road", "West_Terminal", "Industrial_Zone", "Stadium"
    }

    # Encodings for ANN
    VEHICLE_ENCODING = {
        "Ambulance": 3,
        "FireTruck": 3,
        "Police": 2,
        "Civilian": 0,
    }

    SEVERITY_ENCODING = {
        "None": 0,
        "Low": 1,
        "Medium": 2,
        "High": 3,
        "Critical": 4
    }

    SENSITIVITY_ENCODING = {
        "Normal": 0,
        "High": 1
    }

    DENSITY_ENCODING = {
        "Low": 0,
        "Medium": 1,
        "High": 2
    }

    PRIORITY_CLAIM_ENCODING = {
        "No": 0,
        "Yes": 1
    }

    # Distance table
    LOCATION_DISTANCES = {
        ("Central_Junction", "City_Hospital"): 3,
        ("Central_Junction", "North_Station"): 3,
        ("Central_Junction", "East_Market"): 2,
        ("Central_Junction", "West_Terminal"): 2,
        ("Central_Junction", "South_Residential"): 3,
        ("North_Station", "River_Bridge"): 4,
        ("North_Station", "Traffic_Control_Center"): 2,
        ("River_Bridge", "Police_HQ"): 2,
        ("River_Bridge", "Stadium"): 3,
        ("East_Market", "South_Residential"): 2,
        ("East_Market", "Stadium"): 3,
        ("South_Residential", "City_Hospital"): 2,
        ("South_Residential", "Airport_Road"): 4,
        ("West_Terminal", "Industrial_Zone"): 2,
        ("West_Terminal", "Fire_Station"): 2,
        ("Industrial_Zone", "East_Market"): 3,
        ("Stadium", "Airport_Road"): 3,
        ("Traffic_Control_Center", "Police_HQ"): 2,
        ("City_Hospital", "East_Market"): 3,
        ("Fire_Station", "Central_Junction"): 3,
    }

    # Estimate distance
    def _estimate_distance(self, src, dst):

        key1 = (src, dst)
        key2 = (dst, src)

        return self.LOCATION_DISTANCES.get(
            key1,
            self.LOCATION_DISTANCES.get(key2, 5)
        )

    # Normalize values
    def _normalize(self, value, valid_set, default):

        if isinstance(value, str):

            for v in valid_set:

                if v.lower() == value.strip().lower():
                    return v

        return default

    # Main processing function
    def process(self, raw_request):

        errors = []

        cleaned = {}

        # Request ID
        cleaned["request_id"] = (
            str(raw_request.get("request_id", "REQ-000")).strip()
            or "REQ-000"
        )

        # Vehicle type
        cleaned["vehicle_type"] = self._normalize(
            raw_request.get("vehicle_type", ""),
            self.VALID_VEHICLE_TYPES,
            None
        )

        if not cleaned["vehicle_type"]:

            errors.append("Invalid vehicle type.")

            cleaned["vehicle_type"] = "Civilian"

        # Request category
        cleaned["request_category"] = self._normalize(
            raw_request.get("request_category", ""),
            self.VALID_CATEGORIES,
            None
        )

        if not cleaned["request_category"]:

            errors.append("Invalid request category.")

            cleaned["request_category"] = "Route_Request"

        # Locations
        src = str(
            raw_request.get("current_location", "")
        ).strip()

        dst = str(
            raw_request.get("destination", "")
        ).strip()

        cleaned["current_location"] = self._normalize(
            src,
            self.VALID_LOCATIONS,
            src
        )

        cleaned["destination"] = self._normalize(
            dst,
            self.VALID_LOCATIONS,
            dst
        )

        if not cleaned["current_location"]:
            errors.append("Missing current location.")

        if not cleaned["destination"]:
            errors.append("Missing destination.")

        if cleaned["current_location"] == cleaned["destination"]:
            errors.append("Source and destination must differ.")

        # Other fields
        cleaned["incident_severity"] = self._normalize(
            raw_request.get("incident_severity", "None"),
            self.VALID_SEVERITIES,
            "None"
        )

        cleaned["time_sensitivity"] = self._normalize(
            raw_request.get("time_sensitivity", "Normal"),
            self.VALID_SENSITIVITIES,
            "Normal"
        )

        cleaned["traffic_density"] = self._normalize(
            raw_request.get("traffic_density", "Medium"),
            self.VALID_DENSITIES,
            "Medium"
        )

        cleaned["priority_claim"] = self._normalize(
            raw_request.get("priority_claim", "No"),
            self.VALID_PRIORITY_CLAIMS,
            "No"
        )

        cleaned["control_zone"] = (
            str(raw_request.get("control_zone", "Central_Zone")).strip()
            or "Central_Zone"
        )

        cleaned["description_note"] = str(
            raw_request.get("description_note", "")
        ).strip()

        # Derived values
        cleaned["is_emergency_vehicle"] = (
            cleaned["vehicle_type"]
            in {"Ambulance", "FireTruck", "Police"}
        )

        cleaned["is_hospital_destination"] = (
            cleaned["destination"] == "City_Hospital"
        )

        cleaned["estimated_distance"] = self._estimate_distance(
            cleaned["current_location"],
            cleaned["destination"]
        )

        # ANN features
        cleaned["ann_features"] = [
            self.VEHICLE_ENCODING.get(
                cleaned["vehicle_type"], 0
            ),

            self.SEVERITY_ENCODING.get(
                cleaned["incident_severity"], 0
            ),

            self.SENSITIVITY_ENCODING.get(
                cleaned["time_sensitivity"], 0
            ),

            self.DENSITY_ENCODING.get(
                cleaned["traffic_density"], 1
            ),

            cleaned["estimated_distance"],

            self.PRIORITY_CLAIM_ENCODING.get(
                cleaned["priority_claim"], 0
            ),
        ]

        cleaned["valid"] = len(errors) == 0

        cleaned["errors"] = errors

        return cleaned