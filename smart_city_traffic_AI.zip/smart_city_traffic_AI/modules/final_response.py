"""Module 7: Final Response Layer"""


class FinalResponseLayer:

    # Generate final response
    def generate(self, results):

        pipeline = results.get("pipeline", [])
        request = results.get("request", {})
        lines = []

        sep = "─" * 63

        lines.append(sep)
        lines.append(f"  REQUEST ID   : {request.get('request_id', 'N/A')}")
        lines.append(f"  CATEGORY     : {request.get('request_category', 'N/A')}")
        lines.append(f"  VEHICLE      : {request.get('vehicle_type', 'N/A')}")
        lines.append(
            f"  ROUTE        : {request.get('current_location', 'N/A')} "
            f"→ {request.get('destination', 'N/A')}"
        )
        lines.append(sep)

        # ANN results
        if "ANN" in pipeline and "ann" in results:
            ann = results["ann"]

            lines.append("  [ANN PRIORITY PREDICTION]")

            urgency = "URGENT" if ann["binary"] == 1 else "NON-URGENT"

            lines.append(
                f"    Binary Classification : {urgency} "
                f"(confidence: {ann['binary_confidence']})"
            )

            lines.append(
                f"    Priority Level        : {ann['priority_label']}"
            )

            score_str = "  ".join(
                f"{k}:{v}" for k, v in ann["scores"].items()
            )

            lines.append(
                f"    Class Probabilities   : {score_str}"
            )

            lines.append("")

        # Knowledge Base results
        if "KB" in pipeline and "kb" in results:

            kb = results["kb"]

            lines.append("  [POLICY VALIDATION — Knowledge Base]")

            status = "✓ APPROVED" if kb["approved"] else "✗ REJECTED"

            lines.append(
                f"    Decision              : {status}"
            )

            lines.append(
                f"    Derived Priority      : {kb['priority']}"
            )

            if kb["authorized_actions"]:
                lines.append(
                    f"    Authorized Actions    : "
                    f"{', '.join(kb['authorized_actions'])}"
                )

            if kb["allowed_actions"]:
                lines.append(
                    f"    Allowed Actions       : "
                    f"{', '.join(kb['allowed_actions'])}"
                )

            if kb["emergency_corridor"]:
                lines.append(
                    "    Emergency Corridor    : ACTIVATED"
                )

            lines.append("")

        # CSP results
        if "CSP" in pipeline and "csp" in results:

            csp = results["csp"]

            lines.append(
                "  [SIGNAL CONTROL ALLOCATION — CSP Scheduler]"
            )

            if csp["feasible"]:

                lines.append(
                    "    Status                : Feasible plan found"
                )

                for sid, phase in sorted(csp["assignments"].items()):

                    name = csp["station_names"].get(sid, sid)

                    emg = (
                        " ← Emergency Priority"
                        if sid in csp["emergency_stations"]
                        else ""
                    )

                    lines.append(
                        f"    {sid} ({name:<22}) → {phase}{emg}"
                    )

            else:

                lines.append(
                    f"    Status                : {csp['message']}"
                )

            lines.append("")

        # Search module results
        if "Search" in pipeline and "search" in results:

            search = results["search"]

            lines.append(
                "  [ROUTE NAVIGATION — Search Module]"
            )

            lines.append(
                f"    Algorithm Used        : {search['algorithm']}"
            )

            if search["path"]:

                route_str = " → ".join(search["path"])

                lines.append(
                    f"    Route                 : {route_str}"
                )

                lines.append(
                    f"    Number of Hops        : {search['hops']}"
                )

                if search["total_cost"] is not None:

                    lines.append(
                        f"    Total Route Cost      : "
                        f"{search['total_cost']} units"
                    )

            else:

                lines.append(
                    f"    Route Status          : {search['message']}"
                )

            lines.append("")

        # Final system decision
        lines.append(sep)

        summary = self._build_summary(results, pipeline)

        lines.append(f"  SYSTEM DECISION: {summary}")

        lines.append(sep)

        return "\n".join(lines)

    # Build summary message
    def _build_summary(self, results, pipeline):

        request = results.get("request", {})

        category = request.get("request_category", "")
        vehicle = request.get("vehicle_type", "Unknown")
        src = request.get("current_location", "?")
        dst = request.get("destination", "?")

        kb = results.get("kb", None)
        ann = results.get("ann", None)
        search = results.get("search", None)
        csp = results.get("csp", None)

        # Route request
        if category == "Route_Request":

            if search and search["path"]:

                return (
                    f"Route approved for {vehicle}. "
                    f"Recommended path: {' → '.join(search['path'])} "
                    f"({search['hops']} hops)."
                )

            else:

                return (
                    f"No route available between {src} and {dst}."
                )

        # Policy check
        elif category == "Policy_Check":

            if kb and kb["approved"]:

                return (
                    f"Policy check APPROVED. {vehicle} is authorized for "
                    f"{', '.join(kb['authorized_actions']) or 'requested action'}."
                )

            else:

                return (
                    f"Policy check REJECTED. "
                    f"{vehicle} is not authorized."
                )

        # Control allocation
        elif category == "Control_Allocation_Request":

            if kb and kb["approved"] and csp and csp["feasible"]:

                return (
                    f"Control allocation APPROVED. "
                    f"Signal plan assigned across "
                    f"{len(csp['assignments'])} stations."
                )

            else:

                return (
                    "Control allocation could not be completed."
                )

        # Emergency request
        elif category == "Emergency_Response_Request":

            if kb and kb["approved"]:

                priority = kb["priority"]

                route_info = ""
                if search and search["path"]:
                    route_info = (
                        f" Fastest route: "
                        f"{' → '.join(search['path'])}."
                    )

                ctrl_info = ""
                if csp and csp["feasible"]:
                    ctrl_info = " Signal corridors coordinated."

                return (
                    f"EMERGENCY APPROVED. Priority: {priority}. "
                    f"{vehicle} cleared to {dst}."
                    f"{route_info}{ctrl_info}"
                )

            else:

                return (
                    f"Emergency request REJECTED. "
                    f"{vehicle} not authorized."
                )

        # Integrated service request
        elif category == "Integrated_City_Service_Request":

            if kb and kb["approved"]:

                priority = kb["priority"]

                parts = [
                    f"INTEGRATED RESPONSE APPROVED. Priority: {priority}."
                ]

                if ann:
                    parts.append(
                        f"ANN urgency: {ann['priority_label']}."
                    )

                if csp and csp["feasible"]:
                    parts.append(
                        f"Signal plan: "
                        f"{len(csp['assignments'])} stations assigned."
                    )

                if search and search["path"]:
                    parts.append(
                        f"Route: {' → '.join(search['path'])} "
                        f"(cost: {search['total_cost']})."
                    )

                return " ".join(parts)

            else:

                return (
                    "Integrated service request REJECTED."
                )

        return "Request processed."